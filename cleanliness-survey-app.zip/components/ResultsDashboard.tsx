
import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { SurveyResponse } from '../types';
import { summarizeFeedback } from '../services/geminiService';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';

interface ResultsDashboardProps {
  responses: SurveyResponse[];
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE'];

export default function ResultsDashboard({ responses }: ResultsDashboardProps) {
  const [summary, setSummary] = useState('');
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [summaryError, setSummaryError] = useState('');

  const averageRatings = useMemo(() => {
    if (responses.length === 0) {
      return { overall: 0, restroom: 0, commonArea: 0 };
    }
    const total = responses.reduce((acc, res) => ({
      overall: acc.overall + res.overallCleanliness,
      restroom: acc.restroom + res.restroomCleanliness,
      commonArea: acc.commonArea + res.commonAreaCleanliness,
    }), { overall: 0, restroom: 0, commonArea: 0 });

    return {
      overall: parseFloat((total.overall / responses.length).toFixed(2)),
      restroom: parseFloat((total.restroom / responses.length).toFixed(2)),
      commonArea: parseFloat((total.commonArea / responses.length).toFixed(2)),
    };
  }, [responses]);

  const chartData = useMemo(() => [
    { name: 'Overall', 'Average Rating': averageRatings.overall },
    { name: 'Restrooms', 'Average Rating': averageRatings.restroom },
    { name: 'Common Areas', 'Average Rating': averageRatings.commonArea },
  ], [averageRatings]);

  const ratingDistribution = useMemo(() => {
    const distribution = [
      { name: '1 Star', value: 0 },
      { name: '2 Stars', value: 0 },
      { name: '3 Stars', value: 0 },
      { name: '4 Stars', value: 0 },
      { name: '5 Stars', value: 0 },
    ];
    responses.forEach(res => {
      distribution[res.overallCleanliness - 1].value++;
    });
    return distribution.filter(d => d.value > 0);
  }, [responses]);

  const textFeedback = useMemo(() =>
    responses
      .filter(r => r.improvements.trim() !== '')
      .map(r => ({ name: r.name, feedback: r.improvements })), 
    [responses]
  );

  const handleGenerateSummary = async () => {
    if (textFeedback.length === 0) {
      setSummaryError("No feedback available to summarize.");
      return;
    }
    setLoadingSummary(true);
    setSummaryError('');
    setSummary('');
    try {
      const feedbackStrings = textFeedback.map(item => item.feedback);
      const result = await summarizeFeedback(feedbackStrings);
      setSummary(result);
    } catch (error) {
      console.error("Error generating summary:", error);
      setSummaryError("Failed to generate AI summary. Please check your API key and try again.");
    } finally {
      setLoadingSummary(false);
    }
  };

  if (responses.length === 0) {
    return (
      <Card>
        <div className="p-8 text-center">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">No Responses Yet</h2>
          <p className="mt-2 text-slate-600 dark:text-slate-400">As soon as surveys are submitted, the results will appear here.</p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Survey Results ({responses.length} responses)</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <div className="p-6">
            <h3 className="font-bold text-xl mb-4">Average Ratings</h3>
            <div style={{ width: '100%', height: 300 }}>
              <ResponsiveContainer>
                <BarChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-700" />
                  <XAxis dataKey="name" className="text-sm fill-slate-600 dark:fill-slate-400" />
                  <YAxis domain={[0, 5]} className="text-sm fill-slate-600 dark:fill-slate-400" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
                      backdropFilter: 'blur(5px)',
                      border: '1px solid #e2e8f0',
                      borderRadius: '0.5rem',
                      color: '#334155'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="Average Rating" fill="#4f46e5" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>
        <Card>
          <div className="p-6">
            <h3 className="font-bold text-xl mb-4">Overall Cleanliness Distribution</h3>
            <div style={{ width: '100%', height: 300 }}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={ratingDistribution} cx="50%" cy="50%" labelLine={false} outerRadius={110} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                    {ratingDistribution.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <div className="p-6">
          <h3 className="font-bold text-xl mb-4">AI-Powered Feedback Summary</h3>
          {textFeedback.length > 0 ? (
            <>
              <Button onClick={handleGenerateSummary} disabled={loadingSummary}>
                {loadingSummary ? <><Spinner /> Generating...</> : "Generate Summary"}
              </Button>
              {loadingSummary && <p className="mt-4 text-sm text-slate-500">The AI is thinking... This might take a moment.</p>}
              {summaryError && <p className="mt-4 text-sm text-red-500">{summaryError}</p>}
              {summary && (
                <div className="mt-4 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg whitespace-pre-wrap">
                   <p className="text-slate-700 dark:text-slate-300">{summary}</p>
                </div>
              )}
            </>
          ) : (
            <p className="text-slate-500">No written feedback has been provided to summarize.</p>
          )}
        </div>
      </Card>
      
      <Card>
        <div className="p-6">
          <h3 className="font-bold text-xl mb-4">Improvement Suggestions</h3>
          {textFeedback.length > 0 ? (
            <ul className="space-y-4 max-h-96 overflow-y-auto">
              {textFeedback.map((item, index) => (
                <li key={index} className="p-4 bg-slate-100 dark:bg-slate-800 rounded-lg border-l-4 border-indigo-500">
                  <p className="text-slate-700 dark:text-slate-300 italic">"{item.feedback}"</p>
                  <p className="text-right text-sm text-slate-500 dark:text-slate-400 mt-2 font-semibold">- {item.name}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500">No written feedback has been provided.</p>
          )}
        </div>
      </Card>

    </div>
  );
}