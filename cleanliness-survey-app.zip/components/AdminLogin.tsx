
import React, { useState } from 'react';
import Button from './common/Button';
import Card from './common/Card';

interface AdminLoginProps {
  onLogin: (pin: string) => void;
  error: string | null;
}

export default function AdminLogin({ onLogin, error }: AdminLoginProps) {
  const [pin, setPin] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(pin);
  };

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <div className="p-8">
          <h2 className="text-center text-2xl font-bold text-slate-800 dark:text-white mb-4">Admin Access</h2>
          <p className="text-center text-slate-600 dark:text-slate-400 mb-6">Enter your PIN to view survey results.</p>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="pin" className="sr-only">PIN</label>
              <input
                id="pin"
                name="pin"
                type="password"
                autoComplete="current-password"
                required
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Enter PIN"
                className="w-full text-center p-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              />
            </div>
            
            {error && (
              <p className="text-sm text-red-500 text-center">{error}</p>
            )}

            <div>
              <Button type="submit" className="w-full">
                View Results
              </Button>
            </div>
          </form>
        </div>
      </Card>
    </div>
  );
}
