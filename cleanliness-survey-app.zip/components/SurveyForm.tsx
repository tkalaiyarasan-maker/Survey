
import React, { useState } from 'react';
import { SurveyResponse } from '../types';
import Button from './common/Button';
import Card from './common/Card';

interface SurveyFormProps {
  onSubmit: (response: SurveyResponse) => void;
}

const RatingScale = ({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) => (
  <div className="mb-6">
    <label className="block text-lg font-medium text-slate-700 dark:text-slate-300 mb-3">{label}</label>
    <div className="flex justify-between items-center space-x-2">
      <span className="text-sm text-slate-500">Poor</span>
      {[1, 2, 3, 4, 5].map((rating) => (
        <button
          key={rating}
          type="button"
          onClick={() => onChange(rating)}
          className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-lg font-bold transition-transform transform hover:scale-110 ${
            value === rating
              ? 'bg-indigo-600 text-white shadow-lg scale-110'
              : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-200'
          }`}
        >
          {rating}
        </button>
      ))}
      <span className="text-sm text-slate-500">Excellent</span>
    </div>
  </div>
);


export default function SurveyForm({ onSubmit }: SurveyFormProps) {
  const [name, setName] = useState('');
  const [overallCleanliness, setOverallCleanliness] = useState(0);
  const [restroomCleanliness, setRestroomCleanliness] = useState(0);
  const [commonAreaCleanliness, setCommonAreaCleanliness] = useState(0);
  const [improvements, setImprovements] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() === '' || overallCleanliness === 0 || restroomCleanliness === 0 || commonAreaCleanliness === 0) {
      alert('Please enter your name and rate all categories before submitting.');
      return;
    }
    onSubmit({
      name,
      overallCleanliness,
      restroomCleanliness,
      commonAreaCleanliness,
      improvements,
      timestamp: new Date(),
    });

    // Reset form and show thank you message
    setSubmitted(true);
    setTimeout(() => {
        setName('');
        setOverallCleanliness(0);
        setRestroomCleanliness(0);
        setCommonAreaCleanliness(0);
        setImprovements('');
        setSubmitted(false);
    }, 5000);
  };

  if (submitted) {
    return (
      <Card>
        <div className="text-center p-8">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h2 className="mt-4 text-2xl font-bold text-slate-800 dark:text-white">Thank You!</h2>
            <p className="mt-2 text-slate-600 dark:text-slate-400">Your feedback has been submitted successfully.</p>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="p-6 sm:p-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-white mb-2">Share Your Feedback</h2>
        <p className="text-slate-600 dark:text-slate-400 mb-8">Help us improve our facilities by answering a few questions.</p>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="name" className="block text-lg font-medium text-slate-700 dark:text-slate-300 mb-2">
              1. Your Name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Please enter your name"
              required
              className="w-full p-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>

          <RatingScale label="2. How would you rate the overall cleanliness?" value={overallCleanliness} onChange={setOverallCleanliness} />
          <RatingScale label="3. How would you rate the cleanliness of the restrooms?" value={restroomCleanliness} onChange={setRestroomCleanliness} />
          <RatingScale label="4. How would you rate the cleanliness of the common areas (e.g., lobby, hallways)?" value={commonAreaCleanliness} onChange={setCommonAreaCleanliness} />

          <div className="mb-6">
            <label htmlFor="improvements" className="block text-lg font-medium text-slate-700 dark:text-slate-300 mb-2">
              5. Do you have any suggestions for improvement? (Optional)
            </label>
            <textarea
              id="improvements"
              rows={4}
              value={improvements}
              onChange={(e) => setImprovements(e.target.value)}
              placeholder="Tell us what we can do better..."
              className="w-full p-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>
          
          <div className="mt-8">
            <Button type="submit" className="w-full">
              Submit Feedback
            </Button>
          </div>
        </form>
      </div>
    </Card>
  );
}