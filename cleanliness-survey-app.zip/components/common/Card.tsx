import React, { ReactNode } from 'react';

interface CardProps {
  // Fix: Made children optional to resolve type errors where the checker incorrectly fails to identify children passed to the component.
  children?: ReactNode;
  className?: string;
}

export default function Card({ children, className = '' }: CardProps) {
  return (
    <div className={`bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden transition-shadow hover:shadow-2xl ${className}`}>
      {children}
    </div>
  );
}
