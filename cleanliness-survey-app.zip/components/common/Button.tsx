import React, { ReactNode, ButtonHTMLAttributes } from 'react';

// Fix: Switched from interface to a type alias with an intersection to ensure HTML attributes are correctly inherited.
// Made children optional to handle cases where the type checker doesn't recognize children passed via JSX.
type ButtonProps = {
  children?: ReactNode;
  className?: string;
} & ButtonHTMLAttributes<HTMLButtonElement>;

export default function Button({ children, className = '', ...props }: ButtonProps) {
  return (
    <button
      {...props}
      className={`inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors ${className}`}
    >
      {children}
    </button>
  );
}
