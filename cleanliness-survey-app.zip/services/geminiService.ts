
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function summarizeFeedback(feedback: string[]): Promise<string> {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  const model = 'gemini-2.5-flash';

  const prompt = `
    You are an assistant who summarizes feedback for a facilities manager.
    The following is a list of feedback comments regarding the cleanliness of a building.
    Please provide a concise, bulleted summary of the key themes and actionable suggestions.
    Categorize the feedback if possible (e.g., Restrooms, Common Areas, Specific Suggestions).

    Feedback to analyze:
    ${feedback.map(f => `- "${f}"`).join('\n')}
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw new Error("Failed to communicate with the Gemini API.");
  }
}
